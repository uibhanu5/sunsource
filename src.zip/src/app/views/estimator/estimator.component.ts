import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-estimator',
  templateUrl: './estimator.component.html',
  styleUrls: ['./estimator.component.css']
})
export class EstimatorComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
