import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-installers',
  templateUrl: './installers.component.html',
  styleUrls: ['./installers.component.css']
})
export class InstallersComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
