import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-solar-availability',
  templateUrl: './solar-availability.component.html',
  styleUrls: ['./solar-availability.component.css']
})
export class SolarAvailabilityComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
